/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista.interfaces;

import javax.swing.JPanel;

/**
 *
 * @author Carlos
 */
public interface ConstantesMenu {
    public static int MENU_VACIO = 0;
    public static int MENU_ESTUDIANTE = 1;
    public static int MENU_DOCENTE = 2;
    public static int MENU_DIRECTIVO = 3;
    public static int MENU_ACUDIENTE = 4;
    public static int MENU_PERSONAL = 5;
    
    public static int MENU_DIRECTIVO_X = 325;
    public static int MENU_DIRECTIVO_Y = 898;
}

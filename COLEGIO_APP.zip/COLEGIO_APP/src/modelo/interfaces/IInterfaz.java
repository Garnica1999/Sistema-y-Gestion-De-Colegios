/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.interfaces;

/**
 *
 * @author Carlos
 */
public interface IInterfaz {
    public static final String COLOR_AMARILLO = "Amarillo";
    public static final String COLOR_VERDE = "Verde";
    public static final String COLOR_MORADO = "Morado";
    public static final String COLOR_AZUL = "Azul";
    public static final String COLOR_ROJO = "Rojo";
    public static final String COLOR_NARANJA = "Naranja";
    public static final String COLOR_MODO_NOCHE = "Gris";
    public static final String COLOR_DEFECTO = "Blanco";
}
